Name: Sagar Mangulkar

1) How to run program:

Extract corpora_assignment.tar.gz to corpora_assignment direcoty in terminal by below command:

$ tar -zxvf corpora_assignment.tar.gz

Go inside this extracted directory corpora_assignment from terminal. Run below command in terminal.

$ java -jar corpora_assignment.jar adjs.json crayola.json occupations.json

2) Output:

AlmondMiningServiceUnitOperatorUnsupervised
<User input: Enter>
SeaGreenEnglishLanguageTeacherBlushing
<User input: Enter>
BrickRedSewerPipeCleanerDetective
<User input: Enter>
.
.
.
.
<Ctrl + C> or Posible Uuids are finished
Thank you.
